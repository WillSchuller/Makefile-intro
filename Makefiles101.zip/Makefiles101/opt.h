//********************************************************************
//
// Operating Systems
// Programming Project #5: Paging Simulation
// Due, Thu Dec 6, 2005
// Instructor: Michael C. Scherger
//
//********************************************************************
#ifndef OPT_H
#define OPT_H
int opt();
#endif
#ifndef MAIN_CPP
#include <list>
using namespace std;
extern list<int> references;
extern int buffersize;
#endif
